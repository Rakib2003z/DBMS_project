SELECT student.name, takes.grade
FROM student
JOIN takes ON student.ID = takes.ID
WHERE takes.course_id LIKE '%CS%';
Select * from takes;