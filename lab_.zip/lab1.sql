select name ,dept_name from instructor 
where salary >20000;
select * from student