DELIMITER //
CREATE PROCEDURE adjust_budget(IN p_dept_name VARCHAR(20),IN p_percent DECIMAL(5,2))
BEGIN
    UPDATE department SET budget = budget*(1 + (p_percent / 100)) WHERE dept_name = p_dept_name;
END
// DELIMITER ;
CALL adjust_budget('Biology', 5);
select * from department;